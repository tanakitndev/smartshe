// const http = "http://localhost:5000";
// const http = "http://webworkpermit-1490777047.ap-southeast-1.elb.amazonaws.com:5000";
// const http = "http://localhost:5000";
// const http = "http://10.53.91.116:5000";
// const http = "http://ptfwebsite.ddns.net:5000";

const http = "http://ec2-54-255-158-119.ap-southeast-1.compute.amazonaws.com:5000";
// const http = "http://ptfwebsite.ddns.net:5000";
export default http;