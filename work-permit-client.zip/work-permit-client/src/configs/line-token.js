const lineToken = "eh5BWo3ORqqpZmGR2icFcdCH1PbAen0Zh74tvyVdvAR";
export default lineToken;