const rootPath = '/wpm-client';

export default rootPath;