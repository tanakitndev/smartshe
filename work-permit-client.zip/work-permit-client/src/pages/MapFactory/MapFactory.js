import React, { Component } from 'react'
import MapFactoryComponent from '../../components/MapFactory';

export default class MapFactory extends Component {
    render() {
        return (
            <div>
                <MapFactoryComponent />
            </div>
        )
    }
}
